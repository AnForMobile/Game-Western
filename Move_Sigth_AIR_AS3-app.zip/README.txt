
Readme file:

To test these files: // https://helpx.adobe.com/animate/using/publishing-air-android-applications.html

1) Open the ".fla" file in Adobe Animate 2019, 2020 or 2021 [https://www.adobe.com/products/animate.html];

2) Then, fill in the publishing settings for Android or iOS;

3) Use a USB device to test the APP directly on your mobile device;

4) When performing the test, your ".APK" file will also be generated.


PS .: AIR SDK is already installed in Adobe Animate, but if necessary, update to the latest version: https://airsdk.harman.com/download

If in doubt, use ActionScript 3.0-related groups for more information:

A) https://www.facebook.com/groups/asformobile/
B) https://www.facebook.com/groups/actionscriptAS3
C) https://www.facebook.com/groups/118921458138790
D) https://www.facebook.com/groups/AdobeAnimateTutorials
E) https://www.facebook.com/groups/1918854015096236
F) https://www.facebook.com/groups/AnimateAS3Air
G) https://www.facebook.com/groups/757838257621789

Like our page: https://www.facebook.com/Adobe-Animate-for-Mobile-112308407118212/